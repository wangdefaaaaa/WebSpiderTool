//导入依赖
const express = require('express');
const { Pool } = require('pg');
const cheerio = require('cheerio');
const axios = require('axios');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const path = require('path');
const fs = require('fs');
const cors = require('cors');
const helmet = require('helmet');
const winston = require('winston');
const archiver = require('archiver');
const nodemailer = require('nodemailer');
const speakeasy = require('speakeasy');
const session = require('express-session');

const app = express();

//定义全局logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp({
      format: 'YYYY-MM-DD HH:mm:ss'
    }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'app.log' })
  ]
});

//全局异常捕获
process.on('uncaughtException', (err) => {
  logger.error('未捕获异常:', err);
  console.error('严重错误，但服务将继续运行:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('未处理的Promise拒绝:', { reason, promise });
  console.error('未处理的Promise拒绝:', reason);
});

// 会话配置
app.use(session({
  secret: 'web-spider-captcha-secret-2025',
  resave: false,
  saveUninitialized: true,
  cookie: { 
    secure: false, // 开发环境设为false，生产环境应设为true
    maxAge: 300000 // 5分钟过期
  }
}));

// 允许跨域访问
app.use(helmet({
  contentSecurityPolicy: false,
  frameguard: false
}));
app.use(cors({
  credentials: true, // 允许携带cookie
  origin: true
}));
app.use(express.json());

// 严格按照如下方式配置静态资源(不得篡改)
const publicPath = path.resolve(__dirname, '../frontend/public');
app.use(express.static(publicPath));

// JWT密钥
const JWT_SECRET = 'web-spider-secret-key-2025';

// PostgreSQL数据库连接配置
const dbConfig = {
  user: process.env.DB_USER || 'postgres',
  host: process.env.DB_HOST || 'localhost',
  database: process.env.DB_NAME || 'web_spider',
  password: process.env.DB_PASSWORD || 'password',
  port: process.env.DB_PORT || 5432,
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
};

const pool = new Pool(dbConfig);

// 验证码存储
const verificationCodes = {};
const lastRegisterTimes = {};

// 邮件发送配置
const transporter = nodemailer.createTransport({
  service: process.env.EMAIL_SERVICE || 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
});

// 数据库操作包装函数
async function runQuery(text, params) {
  const client = await pool.connect();
  try {
    const result = await client.query(text, params);
    return result;
  } finally {
    client.release();
  }
}

// 数据库初始化
async function init_database() {
  try {
    // 创建用户表
    await runQuery(`CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      username VARCHAR(255) UNIQUE NOT NULL,
      email VARCHAR(255) UNIQUE NOT NULL,
      password TEXT NOT NULL,
      is_admin BOOLEAN DEFAULT FALSE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`);
    
    // 创建使用记录表
    await runQuery(`CREATE TABLE IF NOT EXISTS history (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      url TEXT NOT NULL,
      content_types TEXT,
      timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      expiry_date TIMESTAMP
    )`);
    
    // 创建默认测试账户
    const testPassword = await bcrypt.hash('123456', 10);
    await runQuery(
      `INSERT INTO users (username, email, password) VALUES ($1, $2, $3) ON CONFLICT (username) DO NOTHING`, 
      ['test', 'test@example.com', testPassword]
    );
    
    // 创建默认管理员账户
    const adminPassword = await bcrypt.hash('wdf0716', 10);
    await runQuery(
      `INSERT INTO users (username, email, password, is_admin) VALUES ($1, $2, $3, $4) ON CONFLICT (username) DO NOTHING`, 
      ['wdf', 'admin@example.com', adminPassword, true]
    );
    
    logger.info('数据库初始化完成');
  } catch (error) {
    logger.error('数据库初始化失败:', error);
  }
}

// 在这里添加数据库初始化逻辑
init_database();

// 资源清理定时器 - 每小时清理一次过期数据
setInterval(async () => {
  try {
    // 清理过期的验证码
    const now = Date.now();
    Object.keys(verificationCodes).forEach(email => {
      if (verificationCodes[email].expiresAt < now) {
        delete verificationCodes[email];
      }
    });

    // 清理过期的注册时间记录（超过5分钟）
    Object.keys(lastRegisterTimes).forEach(email => {
      if (now - lastRegisterTimes[email] > 300000) {
        delete lastRegisterTimes[email];
      }
    });

    // 清理过期的历史记录
    await runQuery('DELETE FROM history WHERE expiry_date < NOW()');
    
    // 清理临时文件
    const tempDir = path.join(__dirname, 'temp');
    if (fs.existsSync(tempDir)) {
      const files = fs.readdirSync(tempDir);
      files.forEach(file => {
        const filePath = path.join(tempDir, file);
        const stats = fs.statSync(filePath);
        // 删除超过1小时的临时文件
        if (now - stats.mtime.getTime() > 3600000) {
          try {
            fs.unlinkSync(filePath);
            logger.info(`清理临时文件: ${file}`);
          } catch (error) {
            logger.error(`清理临时文件失败: ${file}`, error);
          }
        }
      });
    }

    logger.info('资源清理完成');
  } catch (error) {
    logger.error('资源清理失败:', error);
  }
}, 3600000); // 每小时执行一次

// 安全配置检查
function checkSecurityConfig() {
  const warnings = [];
  
  if (!process.env.EMAIL_USER || !process.env.EMAIL_PASSWORD) {
    warnings.push('邮件服务配置缺失，注册功能可能无法正常工作');
  }
  
  if (process.env.NODE_ENV === 'production') {
    if (!process.env.DB_PASSWORD || process.env.DB_PASSWORD === 'password') {
      warnings.push('生产环境使用默认数据库密码，存在安全风险');
    }
    
    if (JWT_SECRET === 'web-spider-secret-key-2025') {
      warnings.push('生产环境使用默认JWT密钥，存在安全风险');
    }
  }
  
  if (warnings.length > 0) {
    logger.warn('安全配置警告:', warnings);
    console.warn('⚠️ 安全配置警告:');
    warnings.forEach(warning => console.warn(`   - ${warning}`));
  }
}

// 启动时检查安全配置
checkSecurityConfig();

// 生成随机数字验证码
function generateRandomCode(length = 4) {
  const digits = '0123456789';
  let result = '';
  for (let i = 0; i < length; i++) {
    result += digits.charAt(Math.floor(Math.random() * digits.length));
  }
  return result;
}

// 验证JWT token中间件
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ success: false, message: '未提供访问令牌' });
  }
  
  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ success: false, message: '令牌无效' });
    }
    req.user = user;
    next();
  });
}

// 获取验证码API
app.get('/captcha', (req, res) => {
  try {
    const captcha = generateRandomCode(4);
    req.session.captcha = captcha;
    
    logger.info('验证码生成成功', { sessionId: req.sessionID, captcha });
    
    res.json({
      success: true,
      captcha: captcha
    });
  } catch (error) {
    logger.error('验证码生成失败:', error);
    res.status(500).json({
      success: false,
      message: '验证码生成失败'
    });
  }
});

// 用户登录API（包含验证码验证）
app.post('/login', async (req, res) => {
  const { username, password, captcha } = req.body;
  
  if (!username || !password || !captcha) {
    return res.status(400).json({ 
      success: false, 
      message: '请输入用户名、密码和验证码' 
    });
  }

  // 验证验证码
  if (!req.session.captcha || req.session.captcha !== captcha) {
    logger.warn('验证码验证失败', { 
      sessionId: req.sessionID, 
      expected: req.session.captcha, 
      received: captcha 
    });
    return res.status(400).json({
      success: false,
      message: '验证码错误'
    });
  }

  try {
    // 查询用户
    const userResult = await runQuery(
      'SELECT * FROM users WHERE username = $1',
      [username]
    );
    
    if (userResult.rows.length === 0) {
      // 清除验证码
      delete req.session.captcha;
      return res.status(401).json({ 
        success: false, 
        message: '用户名或密码错误' 
      });
    }

    const user = userResult.rows[0];
    
    // 验证密码
    const passwordMatch = await bcrypt.compare(password, user.password);
    
    if (!passwordMatch) {
      // 清除验证码
      delete req.session.captcha;
      return res.status(401).json({ 
        success: false, 
        message: '用户名或密码错误' 
      });
    }

    // 生成JWT令牌
    const token = jwt.sign(
      { 
        id: user.id, 
        username: user.username,
        email: user.email,
        isAdmin: user.is_admin || false
      }, 
      JWT_SECRET, 
      { expiresIn: '30d' }
    );
    
    // 清除验证码
    delete req.session.captcha;
    
    logger.info('用户登录成功', { username: user.username, isAdmin: user.is_admin || false });
    
    res.json({
      success: true,
      message: '登录成功',
      token: token,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        isAdmin: user.is_admin || false
      }
    });
  } catch (error) {
    logger.error('登录失败:', error);
    res.status(500).json({ 
      success: false, 
      message: '登录失败，请重试' 
    });
  }
});

// 发送验证码API
app.post('/send-verification-code', async (req, res) => {
  const { email } = req.body;
  
  if (!email) {
    return res.status(400).json({ success: false, message: '邮箱不能为空' });
  }

  try {
    // 生成6位数字验证码
    const code = speakeasy.totp({
      secret: email + Date.now(),
      digits: 6,
      step: 300 // 5分钟有效期
    });

    // 发送邮件
    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: email,
      subject: 'Web Spider Tool 验证码',
      text: `您的验证码是：${code}，5分钟内有效。`,
      html: `<p>您的验证码是：<strong>${code}</strong>，5分钟内有效。</p>`
    });

    // 存储验证码
    verificationCodes[email] = {
      code,
      expiresAt: Date.now() + 300000 // 5分钟后过期
    };

    res.json({ success: true, message: '验证码已发送' });
  } catch (error) {
    logger.error('发送验证码失败:', error);
    res.status(500).json({ success: false, message: '发送验证码失败' });
  }
});

// 用户注册API
app.post('/register', async (req, res) => {
  const { username, password, email, verificationCode } = req.body;
  
  // 验证必填字段
  if (!username || !password || !email || !verificationCode) {
    return res.status(400).json({ success: false, message: '所有字段都是必填的' });
  }

  // 验证邮箱格式
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ success: false, message: '邮箱格式不正确' });
  }

  // 验证密码格式 (6-12位字母和数字)
  const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,12}$/;
  if (!passwordRegex.test(password)) {
    return res.status(400).json({ 
      success: false, 
      message: '密码必须是6-12位字母和数字的组合，区分大小写' 
    });
  }

  // 验证验证码
  const storedCode = verificationCodes[email];
  if (!storedCode || storedCode.code !== verificationCode || storedCode.expiresAt < Date.now()) {
    return res.status(400).json({ success: false, message: '验证码无效或已过期' });
  }

  // 检查5分钟内是否已经注册过
  if (lastRegisterTimes[email] && Date.now() - lastRegisterTimes[email] < 300000) {
    return res.status(400).json({ success: false, message: '5分钟内只能注册一次' });
  }

  try {
    // 检查用户名和邮箱是否已存在
    const userCheck = await runQuery(
      'SELECT * FROM users WHERE username = $1 OR email = $2',
      [username, email]
    );
    
    if (userCheck.rows.length > 0) {
      return res.status(400).json({ 
        success: false, 
        message: '用户名或邮箱已被注册' 
      });
    }

    // 加密密码
    const hashedPassword = await bcrypt.hash(password, 10);
    
    // 保存用户
    await runQuery(
      'INSERT INTO users (username, email, password, is_admin) VALUES ($1, $2, $3, $4)',
      [username, email, hashedPassword, false]
    );

    // 记录注册时间
    lastRegisterTimes[email] = Date.now();
    
    // 清除验证码
    delete verificationCodes[email];
    
    res.json({ success: true, message: '注册成功' });
  } catch (error) {
    logger.error('注册失败:', error);
    res.status(500).json({ success: false, message: '注册失败' });
  }
});

// 修改密码API
app.post('/reset-password', async (req, res) => {
  const { username, email, newPassword } = req.body;
  
  // 验证必填字段
  if (!username || !email || !newPassword) {
    return res.status(400).json({ success: false, message: '所有字段都是必填的' });
  }

  // 验证密码格式
  const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,12}$/;
  if (!passwordRegex.test(newPassword)) {
    return res.status(400).json({ 
      success: false, 
      message: '密码必须是6-12位字母和数字的组合，区分大小写' 
    });
  }

  try {
    // 验证用户信息
    const user = await runQuery(
      'SELECT * FROM users WHERE username = $1 AND email = $2',
      [username, email]
    );
    
    if (user.rows.length === 0) {
      return res.status(400).json({ 
        success: false, 
        message: '用户名和邮箱不匹配' 
      });
    }

    // 加密新密码
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    
    // 更新密码
    await runQuery(
      'UPDATE users SET password = $1 WHERE username = $2',
      [hashedPassword, username]
    );
    
    res.json({ success: true, message: '密码修改成功' });
  } catch (error) {
    logger.error('修改密码失败:', error);
    res.status(500).json({ success: false, message: '修改密码失败' });
  }
});

// 管理员数据API
app.get('/admin/dashboard', authenticateToken, async (req, res) => {
  // 验证是否为管理员
  if (!req.user.isAdmin) {
    return res.status(403).json({ success: false, message: '权限不足' });
  }

  try {
    // 获取注册总人数
    const userCount = await runQuery('SELECT COUNT(*) FROM users');
    const totalUsers = userCount.rows[0].count;
    
    // 获取日均使用量
    const usageStats = await runQuery(`
      SELECT 
        COUNT(*) as total_scans,
        COUNT(DISTINCT user_id) as active_users,
        COUNT(*) / NULLIF(EXTRACT(DAY FROM NOW() - MIN(timestamp)), 0) as daily_avg
      FROM history
    `);
    
    res.json({
      success: true,
      data: {
        totalUsers,
        totalScans: usageStats.rows[0].total_scans,
        activeUsers: usageStats.rows[0].active_users,
        dailyAverage: Math.round(usageStats.rows[0].daily_avg || 0)
      }
    });
  } catch (error) {
    logger.error('获取管理员数据失败:', error);
    res.status(500).json({ success: false, message: '获取数据失败' });
  }
});

// 网页扫描API
app.post('/scan', authenticateToken, async (req, res) => {
  const { url } = req.body;
  
  if (!url) {
    return res.status(400).json({ 
      success: false, 
      message: 'URL不能为空' 
    });
  }

  try {
    new URL(url);
  } catch (error) {
    return res.status(400).json({ 
      success: false, 
      message: 'URL格式无效' 
    });
  }

  try {
    const response = await axios.get(url, {
      timeout: 10000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      }
    });

    const $ = cheerio.load(response.data);
    const contentTypes = {
      images: [],
      videos: [],
      audios: [],
      streams: []
    };

    // 提取图片（包括WebP格式）
    $('img').each((i, elem) => {
      const src = $(elem).attr('src');
      const alt = $(elem).attr('alt') || '无描述';
      if (src) {
        try {
          const fullUrl = new URL(src, url).href;
          const isWebP = fullUrl.toLowerCase().includes('.webp') || 
                        $(elem).attr('type') === 'image/webp';
          
          contentTypes.images.push({
            type: isWebP ? 'webp' : 'image',
            format: isWebP ? 'webp' : 'image',
            url: fullUrl,
            thumbnail: fullUrl,
            description: alt,
            size: 'unknown'
          });
        } catch (e) {
          logger.warn(`无效图片URL: ${src}`, e);
        }
      }
    });

    // 提取视频
    $('video, iframe[src*=\"youtube\"], iframe[src*=\"vimeo\"]').each((i, elem) => {
      const src = $(elem).attr('src') || $(elem).find('source').attr('src');
      const poster = $(elem).attr('poster');
      if (src) {
        try {
          contentTypes.videos.push({
            type: 'video',
            url: new URL(src, url).href,
            thumbnail: poster ? new URL(poster, url).href : null,
            poster: poster ? new URL(poster, url).href : null,
            description: '视频内容',
            size: 'unknown'
          });
        } catch (e) {
          logger.warn(`无效视频URL: ${src}`, e);
        }
      }
    });

    // 提取音频
    $('audio').each((i, elem) => {
      const src = $(elem).attr('src') || $(elem).find('source').attr('src');
      if (src) {
        try {
          contentTypes.audios.push({
            type: 'audio',
            url: new URL(src, url).href,
            description: '音频内容',
            size: 'unknown'
          });
        } catch (e) {
          logger.warn(`无效音频URL: ${src}`, e);
        }
      }
    });

    // 提取流媒体原始地址
    $('iframe[src*=\"youtube.com\"], iframe[src*=\"vimeo.com\"], iframe[src*=\"bilibili.com\"]').each((i, elem) => {
      const src = $(elem).attr('src');
      if (src) {
        try {
          contentTypes.streams.push({
            type: 'stream',
            url: src,
            description: '流媒体内容',
            size: 'unknown'
          });
        } catch (e) {
          logger.warn(`无效流媒体URL: ${src}`, e);
        }
      }
    });

    // 保存扫描记录
    const expiryDate = new Date();
    expiryDate.setDate(expiryDate.getDate() + 30);

    await runQuery(
      'INSERT INTO history (user_id, url, content_types, expiry_date) VALUES ($1, $2, $3, $4)',
      [req.user.id, url, JSON.stringify(contentTypes), expiryDate.toISOString()]
    );

    res.json({
      success: true,
      message: '扫描完成',
      data: {
        url: url,
        contentTypes: contentTypes,
        summary: {
          images: contentTypes.images.length,
          videos: contentTypes.videos.length,
          audios: contentTypes.audios.length,
          streams: contentTypes.streams.length
        }
      }
    });
  } catch (error) {
    logger.error('网页扫描错误:', error);
    res.status(500).json({
      success: false,
      message: '扫描失败: ' + (error.message || '未知错误')
    });
  }
});

// 下载API
app.post('/download', authenticateToken, async (req, res) => {
  const { selectedItems } = req.body;
  
  if (!selectedItems || !Array.isArray(selectedItems)) {
    return res.status(400).json({
      success: false,
      message: '请选择要下载的内容'
    });
  }

  try {
    // 检查是否为媒体文件批量下载
    const mediaTypes = ['image', 'webp', 'video', 'audio', 'stream'];
    const isMediaBatchDownload = selectedItems.length > 1 && 
                               selectedItems.every(item => mediaTypes.includes(item.type));

    if (isMediaBatchDownload) {
      // 创建临时目录
      const tempDir = path.join(__dirname, 'temp');
      if (!fs.existsSync(tempDir)) {
        fs.mkdirSync(tempDir);
      }

      // 生成唯一文件名
      const zipFileName = `media-files-${Date.now()}.zip`;
      const zipFilePath = path.join(tempDir, zipFileName);

      // 创建ZIP文件
      const output = fs.createWriteStream(zipFilePath);
      const archive = archiver('zip', { zlib: { level: 9 } });

      output.on('close', () => {
        // 设置响应头
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="${zipFileName}"`);
        
        // 发送ZIP文件
        const fileStream = fs.createReadStream(zipFilePath);
        fileStream.pipe(res);

        // 清理临时文件
        fileStream.on('end', () => {
          fs.unlinkSync(zipFilePath);
        });
      });

      archive.on('error', (err) => {
        throw err;
      });

      archive.pipe(output);

      // 添加文件到ZIP包
      for (const item of selectedItems) {
        const mediaUrl = item.url;
        const urlParts = new URL(mediaUrl);
        const pathParts = urlParts.pathname.split('/');
        let fileName = pathParts[pathParts.length - 1];
        
        if (!fileName || fileName === '' || !fileName.includes('.')) {
          const extension = item.type === 'webp' ? 'webp' : 
                           item.type === 'image' ? 'jpg' : 
                           item.type === 'video' ? 'mp4' : 
                           item.type === 'audio' ? 'mp3' : 'bin';
          fileName = `${item.type}-${Date.now()}.${extension}`;
        }
        
        try {
          const response = await axios({
            method: 'get',
            url: mediaUrl,
            responseType: 'stream',
            timeout: 30000,
            headers: {
              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
          });

          archive.append(response.data, { name: fileName });
        } catch (error) {
          console.error(`下载文件失败: ${mediaUrl}`, error);
        }
      }

      archive.finalize();
    } else {
      // 单个文件下载
      const isMediaFile = selectedItems.length === 1 && mediaTypes.includes(selectedItems[0].type);

      if (isMediaFile) {
        const mediaItem = selectedItems[0];
        const mediaUrl = mediaItem.url;
        const response = await axios({
          method: 'get',
          url: mediaUrl,
          responseType: 'arraybuffer',
          timeout: 30000,
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
          }
        });

        const contentType = response.headers['content-type'];
        const urlParts = new URL(mediaUrl);
        const pathParts = urlParts.pathname.split('/');
        let fileName = pathParts[pathParts.length - 1];

        if (!fileName || fileName === '' || !fileName.includes('.')) {
          const extension = mediaItem.type === 'webp' ? 'webp' :
                           contentType ? contentType.split('/')[1] : 'bin';
          fileName = `${mediaItem.type}-${Date.now()}.${extension}`;
        }

        res.setHeader('Content-Type', contentType || 'application/octet-stream');
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.send(Buffer.from(response.data));
      } else {
        // 非媒体文件
        let downloadContent = '# 网页扫描结果下载\n\n';
        downloadContent += `下载时间: ${new Date().toLocaleString()}\n`;
        downloadContent += `用户: ${req.user.username}\n\n`;

        selectedItems.forEach((item, index) => {
          downloadContent += `## 项目 ${index + 1}\n`;
          downloadContent += `类型: ${item.type}\n`;
          downloadContent += `描述: ${item.description}\n`;
          if (item.url) {
            downloadContent += `链接: ${item.url}\n`;
          }
          if (item.content) {
            downloadContent += `内容: ${item.content}\n`;
          }
          downloadContent += `大小: ${item.size}\n\n`;
        });

        res.setHeader('Content-Type', 'text/plain; charset=utf-8');
        res.setHeader('Content-Disposition', `attachment; filename="scan-results-${Date.now()}.txt"`);
        res.send(downloadContent);
      }
    }
  } catch (error) {
    logger.error('下载内容错误:', error);
    res.status(500).json({
      success: false,
      message: '下载失败: ' + (error.message || '未知错误')
    });
  }
});

// 获取历史记录API
app.get('/history', authenticateToken, async (req, res) => {
  try {
    const result = await runQuery(
      'SELECT * FROM history WHERE user_id = $1 AND expiry_date > NOW() ORDER BY timestamp DESC LIMIT 50',
      [req.user.id]
    );

    const history = result.rows.map(record => ({
      id: record.id,
      url: record.url,
      contentTypes: JSON.parse(record.content_types),
      timestamp: record.timestamp
    }));

    res.json({
      success: true,
      data: history
    });
  } catch (error) {
    logger.error('获取历史记录失败:', error);
    res.status(500).json({
      success: false,
      message: '获取历史记录失败'
    });
  }
});

// 前端异常上报接口
app.post('/logs', (req, res) => {
  const { error, userAgent, url, timestamp } = req.body;
  
  logger.error('前端异常上报:', {
    error: error,
    userAgent: userAgent,
    url: url,
    timestamp: timestamp || new Date().toISOString()
  });
  
  res.json({ success: true, message: '异常日志已记录' });
});

// 健康检查接口
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// 处理前端路由
app.get('*', (req, res) => {
  const filePath = path.join(publicPath, req.path);
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.sendFile(path.join(publicPath, 'index.html'));
  }
});

// 处理404错误
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: '接口不存在'
  });
});

// 全局错误处理
app.use((err, req, res, next) => {
  logger.error('全局错误:', err);
  res.status(500).json({
    success: false,
    message: '服务器内部错误'
  });
});

// 应用关闭时清理资源
process.on('SIGINT', () => {
  logger.info('应用关闭，清理资源...');
  pool.end();
});

process.on('SIGTERM', () => {
  logger.info('应用被终止，清理资源...');
  pool.end();
});

const PORT = process.env.PORT || 34051;
app.listen(PORT, () => {
  logger.info(`服务器启动成功，端口: ${PORT}`);
  console.log(`🚀 Web Spider Tool 服务器运行在 http://localhost:${PORT}`);
});