// 全局变量
let currentUser = null;
let scanResults = null;
let isDarkMode = false;
let audioPlayers = new Map(); // 存储音频播放器实例

// DOM元素
const elements = {
    themeToggle: null,
    loginBtn: null,
    logoutBtn: null,
    urlInput: null,
    scanBtn: null,
    loginModal: null,
    loginForm: null,
    usernameInput: null,
    passwordInput: null,
    captchaInput: null,
    captchaDisplay: null,
    refreshCaptchaBtn: null,
    resultsContainer: null,
    downloadBtn: null,
    historyBtn: null,
    historyModal: null,
    historyContainer: null,
    loadingSpinner: null,
    // 新增注册相关元素
    registerBtn: null,
    registerModal: null,
    registerForm: null,
    registerUsernameInput: null,
    registerPasswordInput: null,
    registerEmailInput: null,
    registerCodeInput: null,
    sendCodeBtn: null,
    // 新增密码重置相关元素
    resetPasswordBtn: null,
    resetPasswordModal: null,
    resetPasswordForm: null,
    resetUsernameInput: null,
    resetEmailInput: null,
    resetPasswordInput: null,
    // 管理员仪表盘
    adminDashboard: null
};

// 初始化应用
document.addEventListener('DOMContentLoaded', function() {
    try {
        initializeElements();
        initializeEventListeners();
        initializeTheme();
        checkAuthStatus();
        setupGlobalErrorHandler();
        // 初始化验证码
        fetchCaptcha();
    } catch (error) {
        console.error('应用初始化失败:', error);
        showToast('应用初始化失败', 'error');
    }
});

// 初始化DOM元素
function initializeElements() {
    elements.themeToggle = document.getElementById('themeToggle');
    elements.loginBtn = document.getElementById('loginBtn');
    elements.logoutBtn = document.getElementById('logoutBtn');
    elements.urlInput = document.getElementById('urlInput');
    elements.scanBtn = document.getElementById('scanBtn');
    elements.loginModal = document.getElementById('loginModal');
    elements.loginForm = document.getElementById('loginForm');
    elements.usernameInput = document.getElementById('username');
    elements.passwordInput = document.getElementById('password');
    elements.captchaInput = document.getElementById('captcha');
    elements.captchaDisplay = document.getElementById('captchaDisplay');
    elements.refreshCaptchaBtn = document.getElementById('refreshCaptcha');
    elements.resultsContainer = document.getElementById('resultsContainer');
    elements.downloadBtn = document.getElementById('downloadBtn');
    elements.historyBtn = document.getElementById('historyBtn');
    elements.historyModal = document.getElementById('historyModal');
    elements.historyContainer = document.getElementById('historyContainer');
    elements.loadingSpinner = document.getElementById('loadingSpinner');
    
    // 注册相关元素
    elements.registerBtn = document.getElementById('registerBtn');
    elements.registerModal = document.getElementById('registerModal');
    elements.registerForm = document.getElementById('registerForm');
    elements.registerUsernameInput = document.getElementById('registerUsername');
    elements.registerPasswordInput = document.getElementById('registerPassword');
    elements.registerEmailInput = document.getElementById('registerEmail');
    elements.registerCodeInput = document.getElementById('registerCode');
    elements.sendCodeBtn = document.getElementById('sendCodeBtn');
    
    // 密码重置相关元素
    elements.resetPasswordBtn = document.getElementById('resetPasswordBtn');
    elements.resetPasswordModal = document.getElementById('resetPasswordModal');
    elements.resetPasswordForm = document.getElementById('resetPasswordForm');
    elements.resetUsernameInput = document.getElementById('resetUsername');
    elements.resetEmailInput = document.getElementById('resetEmail');
    elements.resetPasswordInput = document.getElementById('resetPassword');
    
    // 管理员仪表盘
    elements.adminDashboard = document.getElementById('adminDashboard');
}

// 初始化事件监听器
function initializeEventListeners() {
    // 主题切换
    if (elements.themeToggle) {
        elements.themeToggle.addEventListener('click', toggleTheme);
    }

    // 登录相关
    if (elements.loginBtn) {
        elements.loginBtn.addEventListener('click', showLoginModal);
    }
    
    if (elements.logoutBtn) {
        elements.logoutBtn.addEventListener('click', logout);
    }

    if (elements.loginForm) {
        elements.loginForm.addEventListener('submit', handleLogin);
    }
    
    // 验证码刷新按钮
    if (elements.refreshCaptchaBtn) {
        elements.refreshCaptchaBtn.addEventListener('click', fetchCaptcha);
    }

    // 注册相关
    if (elements.registerBtn) {
        elements.registerBtn.addEventListener('click', showRegisterModal);
    }
    
    if (elements.registerForm) {
        elements.registerForm.addEventListener('submit', handleRegister);
    }
    
    if (elements.sendCodeBtn) {
        elements.sendCodeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            sendVerificationCode('register');
        });
    }
    
    // 密码重置相关
    if (elements.resetPasswordBtn) {
        elements.resetPasswordBtn.addEventListener('click', showResetPasswordModal);
    }
    
    if (elements.resetPasswordForm) {
        elements.resetPasswordForm.addEventListener('submit', handleResetPassword);
    }

    // 扫描功能
    if (elements.scanBtn) {
        elements.scanBtn.addEventListener('click', handleScan);
    }

    if (elements.urlInput) {
        elements.urlInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                handleScan();
            }
        });
    }

    // 下载功能
    if (elements.downloadBtn) {
        elements.downloadBtn.addEventListener('click', handleDownload);
    }

    // 历史记录
    if (elements.historyBtn) {
        elements.historyBtn.addEventListener('click', showHistoryModal);
    }

    // 模态框关闭
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal-backdrop')) {
            closeModal(e.target.closest('.modal'));
        }
    });

    // ESC键关闭模态框
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.modal:not(.hidden)');
            if (openModal) {
                closeModal(openModal);
            }
        }
    });
}

// 获取验证码
async function fetchCaptcha() {
    try {
        const response = await fetch('/captcha', {
            method: 'GET',
            credentials: 'include' // 确保携带session cookie
        });
        
        const data = await response.json();
        
        if (data.success && elements.captchaDisplay) {
            elements.captchaDisplay.textContent = data.captcha;
            elements.captchaDisplay.style.fontFamily = 'monospace';
            elements.captchaDisplay.style.fontSize = '18px';
            elements.captchaDisplay.style.fontWeight = 'bold';
            elements.captchaDisplay.style.letterSpacing = '2px';
            elements.captchaDisplay.style.color = isDarkMode ? '#60a5fa' : '#3b82f6';
        } else {
            console.error('获取验证码失败:', data.message);
            showToast('获取验证码失败', 'error');
        }
    } catch (error) {
        console.error('获取验证码请求失败:', error);
        showToast('获取验证码失败，请检查网络连接', 'error');
    }
}

// 初始化主题
function initializeTheme() {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        isDarkMode = true;
        document.documentElement.classList.add('dark');
    }
    updateThemeIcon();
}

// 切换主题
function toggleTheme() {
    try {
        isDarkMode = !isDarkMode;
        document.documentElement.classList.toggle('dark', isDarkMode);
        localStorage.setItem('theme', isDarkMode ? 'dark' : 'light');
        updateThemeIcon();
        
        // 更新验证码显示颜色
        if (elements.captchaDisplay) {
            elements.captchaDisplay.style.color = isDarkMode ? '#60a5fa' : '#3b82f6';
        }
        
        // 添加切换动画
        document.body.classList.add('animate__animated', 'animate__fadeIn');
        setTimeout(() => {
            document.body.classList.remove('animate__animated', 'animate__fadeIn');
        }, 500);
    } catch (error) {
        console.error('主题切换失败:', error);
        showToast('主题切换失败', 'error');
    }
}

// 更新主题图标
function updateThemeIcon() {
    if (elements.themeToggle) {
        elements.themeToggle.innerHTML = isDarkMode ? '☀️' : '🌙';
    }
}

// 检查认证状态
function checkAuthStatus() {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('userData');
    
    if (token && userData) {
        try {
            currentUser = JSON.parse(userData);
            updateAuthUI(true);
            
            // 如果是管理员，显示管理员仪表盘
            if (currentUser.isAdmin) {
                fetchAdminDashboardData();
            }
        } catch (error) {
            console.error('用户数据解析失败:', error);
            localStorage.removeItem('token');
            localStorage.removeItem('userData');
        }
    }
}

// 显示登录模态框
function showLoginModal() {
    if (elements.loginModal) {
        elements.loginModal.classList.remove('hidden');
        elements.loginModal.classList.add('animate__animated', 'animate__fadeIn');
        
        // 获取验证码
        fetchCaptcha();
        
        // 移除输入框提示
        if (elements.usernameInput) {
            elements.usernameInput.placeholder = '';
        }
        if (elements.passwordInput) {
            elements.passwordInput.placeholder = '';
        }
    }
}

// 显示注册模态框
function showRegisterModal() {
    if (elements.registerModal) {
        elements.registerModal.classList.remove('hidden');
        elements.registerModal.classList.add('animate__animated', 'animate__fadeIn');
    }
}

// 显示密码重置模态框
function showResetPasswordModal() {
    if (elements.resetPasswordModal) {
        elements.resetPasswordModal.classList.remove('hidden');
        elements.resetPasswordModal.classList.add('animate__animated', 'animate__fadeIn');
    }
}

// 发送验证码
async function sendVerificationCode(type) {
    let email = '';
    
    if (type === 'register') {
        email = elements.registerEmailInput?.value?.trim();
    }
    
    if (!email) {
        showToast('请输入电子邮箱', 'error');
        return;
    }
    
    // 验证邮箱格式
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showToast('请输入有效的电子邮箱地址', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('/send-verification-code', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('验证码已发送到您的邮箱', 'success');
            
            // 禁用发送按钮60秒
            const sendBtn = elements.sendCodeBtn;
            if (sendBtn) {
                let countdown = 60;
                sendBtn.disabled = true;
                const originalText = sendBtn.textContent;
                sendBtn.textContent = `重新发送(${countdown}s)`;
                
                const timer = setInterval(() => {
                    countdown--;
                    sendBtn.textContent = `重新发送(${countdown}s)`;
                    
                    if (countdown <= 0) {
                        clearInterval(timer);
                        sendBtn.disabled = false;
                        sendBtn.textContent = originalText;
                    }
                }, 1000);
            }
        } else {
            showToast(data.message || '验证码发送失败', 'error');
        }
    } catch (error) {
        console.error('验证码发送失败:', error);
        showToast('验证码发送失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 处理注册
async function handleRegister(e) {
    e.preventDefault();
    
    const username = elements.registerUsernameInput?.value?.trim();
    const password = elements.registerPasswordInput?.value?.trim();
    const email = elements.registerEmailInput?.value?.trim();
    const verificationCode = elements.registerCodeInput?.value?.trim();
    
    if (!username || !password || !email || !verificationCode) {
        showToast('请填写所有必填字段', 'error');
        return;
    }
    
    // 验证密码格式
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,12}$/;
    if (!passwordRegex.test(password)) {
        showToast('密码必须是6-12位字母和数字的组合，区分大小写', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password, email, verificationCode })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('注册成功，请登录', 'success');
            closeModal(elements.registerModal);
            showLoginModal();
            
            // 清空表单
            if (elements.registerForm) {
                elements.registerForm.reset();
            }
        } else {
            showToast(data.message || '注册失败', 'error');
        }
    } catch (error) {
        console.error('注册请求失败:', error);
        showToast('注册请求失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 处理登录
async function handleLogin(e) {
    e.preventDefault();
    
    const username = elements.usernameInput?.value?.trim();
    const password = elements.passwordInput?.value?.trim();
    const captcha = elements.captchaInput?.value?.trim();
    
    if (!username || !password || !captcha) {
        showToast('请输入用户名、密码和验证码', 'error');
        return;
    }

    try {
        showLoading(true);
        
        const response = await fetch('/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include', // 确保携带session cookie
            body: JSON.stringify({ username, password, captcha })
        });

        const data = await response.json();

        if (data.success) {
            currentUser = data.user;
            localStorage.setItem('token', data.token);
            localStorage.setItem('userData', JSON.stringify(data.user));
            
            updateAuthUI(true);
            closeModal(elements.loginModal);
            
            // 如果是管理员，获取并显示管理员仪表盘数据
            if (data.user.isAdmin) {
                showToast('管理员登录成功', 'success');
                fetchAdminDashboardData();
            } else {
                showToast('登录成功', 'success');
            }
            
            // 清空表单
            if (elements.loginForm) {
                elements.loginForm.reset();
            }
        } else {
            showToast(data.message || '登录失败', 'error');
            // 刷新验证码
            fetchCaptcha();
            // 清空验证码输入框
            if (elements.captchaInput) {
                elements.captchaInput.value = '';
            }
        }
    } catch (error) {
        console.error('登录请求失败:', error);
        showToast('登录请求失败，请检查网络连接', 'error');
        // 刷新验证码
        fetchCaptcha();
    } finally {
        showLoading(false);
    }
}

// 处理密码重置
async function handleResetPassword(e) {
    e.preventDefault();
    
    const username = elements.resetUsernameInput?.value?.trim();
    const email = elements.resetEmailInput?.value?.trim();
    const newPassword = elements.resetPasswordInput?.value?.trim();
    
    if (!username || !email || !newPassword) {
        showToast('请填写所有必填字段', 'error');
        return;
    }
    
    // 验证密码格式
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{6,12}$/;
    if (!passwordRegex.test(newPassword)) {
        showToast('密码必须是6-12位字母和数字的组合，区分大小写', 'error');
        return;
    }
    
    try {
        showLoading(true);
        
        const response = await fetch('/reset-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, email, newPassword })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showToast('密码修改成功，请使用新密码登录', 'success');
            closeModal(elements.resetPasswordModal);
            showLoginModal();
            
            // 清空表单
            if (elements.resetPasswordForm) {
                elements.resetPasswordForm.reset();
            }
        } else {
            showToast(data.message || '密码修改失败', 'error');
        }
    } catch (error) {
        console.error('密码修改请求失败:', error);
        showToast('密码修改请求失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 获取管理员仪表盘数据
async function fetchAdminDashboardData() {
    if (!currentUser || !currentUser.isAdmin) return;
    
    try {
        showLoading(true);
        
        const token = localStorage.getItem('token');
        const response = await fetch('/admin/dashboard', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
        
        const data = await response.json();
        
        if (data.success) {
            displayAdminDashboard(data.data);
        } else {
            showToast(data.message || '获取管理员数据失败', 'error');
        }
    } catch (error) {
        console.error('获取管理员数据失败:', error);
        showToast('获取管理员数据失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 显示管理员仪表盘
function displayAdminDashboard(data) {
    if (!elements.adminDashboard) return;
    
    elements.adminDashboard.classList.remove('hidden');
    elements.adminDashboard.classList.add('animate__animated', 'animate__fadeIn');
    
    const { totalUsers, totalScans, activeUsers, dailyAverage } = data;
    
    let html = `
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">管理员仪表盘</h2>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div class="stats-card">
                    <div class="stats-number text-blue-600 dark:text-blue-400">${totalUsers}</div>
                    <div class="stats-label">注册总人数</div>
                </div>
                <div class="stats-card">
                    <div class="stats-number text-green-600 dark:text-green-400">${totalScans}</div>
                    <div class="stats-label">总扫描次数</div>
                </div>
                <div class="stats-card">
                    <div class="stats-number text-purple-600 dark:text-purple-400">${activeUsers}</div>
                    <div class="stats-label">活跃用户数</div>
                </div>
                <div class="stats-card">
                    <div class="stats-number text-yellow-600 dark:text-yellow-400">${dailyAverage}</div>
                    <div class="stats-label">日均使用量</div>
                </div>
            </div>
        </div>
    `;
    
    elements.adminDashboard.innerHTML = html;
}

// 退出登录
function logout() {
    try {
        currentUser = null;
        localStorage.removeItem('token');
        localStorage.removeItem('userData');
        updateAuthUI(false);
        
        // 停止所有音频播放
        stopAllAudio();
        
        // 清空扫描结果
        scanResults = null;
        if (elements.resultsContainer) {
            elements.resultsContainer.innerHTML = '';
            elements.resultsContainer.classList.add('hidden');
        }
        
        // 重置输入框位置
        resetInputPosition();
        
        // 隐藏管理员仪表盘
        if (elements.adminDashboard) {
            elements.adminDashboard.classList.add('hidden');
        }
        
        showToast('已退出登录', 'info');
    } catch (error) {
        console.error('退出登录失败:', error);
        showToast('退出登录失败', 'error');
    }
}

// 更新认证UI
function updateAuthUI(isLoggedIn) {
    if (isLoggedIn && currentUser) {
        // 显示用户信息
        if (elements.loginBtn) {
            elements.loginBtn.classList.add('hidden');
        }
        if (elements.logoutBtn) {
            elements.logoutBtn.classList.remove('hidden');
            elements.logoutBtn.textContent = `${currentUser.username} | 退出`;
        }
        if (elements.historyBtn) {
            elements.historyBtn.classList.remove('hidden');
        }
    } else {
        // 显示登录按钮
        if (elements.loginBtn) {
            elements.loginBtn.classList.remove('hidden');
        }
        if (elements.logoutBtn) {
            elements.logoutBtn.classList.add('hidden');
        }
        if (elements.historyBtn) {
            elements.historyBtn.classList.add('hidden');
        }
    }
}

// 处理网页扫描
async function handleScan() {
    if (!currentUser) {
        showToast('请先登录', 'error');
        showLoginModal();
        return;
    }

    const url = elements.urlInput?.value?.trim();
    if (!url) {
        showToast('请输入要扫描的网页URL', 'error');
        return;
    }

    // 验证URL格式
    try {
        new URL(url);
    } catch (error) {
        showToast('请输入有效的URL地址', 'error');
        return;
    }

    try {
        showLoading(true);
        
        const token = localStorage.getItem('token');
        const response = await fetch('/scan', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ url })
        });

        const data = await response.json();

        if (data.success) {
            scanResults = data.data;
            displayScanResults(data.data);
            moveInputUp();
            showToast('扫描完成', 'success');
        } else {
            showToast(data.message || '扫描失败', 'error');
        }
    } catch (error) {
        console.error('扫描请求失败:', error);
        showToast('扫描请求失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 显示扫描结果
function displayScanResults(data) {
    if (!elements.resultsContainer) return;

    const { contentTypes, summary } = data;
    let html = `
        <div class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 animate__animated animate__fadeInUp">
            <h2 class="text-2xl font-bold text-gray-800 dark:text-white mb-4">扫描结果</h2>
            <div class="mb-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <p class="text-sm text-gray-600 dark:text-gray-300 mb-2">扫描网址: ${data.url}</p>
                <div class="grid grid-cols-2 md:grid-cols-6 gap-4 text-center">
                    <div class="bg-blue-100 dark:bg-blue-900 p-2 rounded">
                        <div class="text-lg font-bold text-blue-600 dark:text-blue-300">${summary.images}</div>
                        <div class="text-xs text-blue-500 dark:text-blue-400">图片</div>
                    </div>
                    <div class="bg-green-100 dark:bg-green-900 p-2 rounded">
                        <div class="text-lg font-bold text-green-600 dark:text-green-300">${summary.links || 0}</div>
                        <div class="text-xs text-green-500 dark:text-green-400">链接</div>
                    </div>
                    <div class="bg-purple-100 dark:bg-purple-900 p-2 rounded">
                        <div class="text-lg font-bold text-purple-600 dark:text-purple-300">${summary.texts || 0}</div>
                        <div class="text-xs text-purple-500 dark:text-purple-400">文本</div>
                    </div>
                    <div class="bg-red-100 dark:bg-red-900 p-2 rounded">
                        <div class="text-lg font-bold text-red-600 dark:text-red-300">${summary.videos}</div>
                        <div class="text-xs text-red-500 dark:text-red-400">视频</div>
                    </div>
                    <div class="bg-yellow-100 dark:bg-yellow-900 p-2 rounded">
                        <div class="text-lg font-bold text-yellow-600 dark:text-yellow-300">${summary.audios}</div>
                        <div class="text-xs text-yellow-500 dark:text-yellow-400">音频</div>
                    </div>
                    <div class="bg-pink-100 dark:bg-pink-900 p-2 rounded">
                        <div class="text-lg font-bold text-pink-600 dark:text-pink-300">${summary.streams || 0}</div>
                        <div class="text-xs text-pink-500 dark:text-pink-400">流媒体</div>
                    </div>
                </div>
            </div>
            <div class="space-y-4">
    `;

    // 显示各类型内容
    Object.keys(contentTypes).forEach(type => {
        const items = contentTypes[type];
        if (items.length > 0) {
            html += `
                <div class="border dark:border-gray-600 rounded-lg p-4">
                    <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-3 flex items-center">
                        <input type="checkbox" id="select-all-${type}" class="mr-2 select-all-checkbox" data-type="${type}">
                        ${getTypeIcon(type)} ${getTypeName(type)} (${items.length})
                    </h3>
                    <div class="space-y-2 max-h-60 overflow-y-auto">
            `;

            items.forEach((item, index) => {
                html += renderMediaItem(item, type, index);
            });

            html += `
                    </div>
                </div>
            `;
        }
    });

    html += `
            </div>
            <div class="mt-6 flex justify-center">
                <button id="downloadBtn" class="bg-blue-500 hover:bg-blue-600 text-white px-6 py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                    📥 下载选中内容
                </button>
            </div>
        </div>
    `;

    elements.resultsContainer.innerHTML = html;
    elements.resultsContainer.classList.remove('hidden');

    // 重新绑定下载按钮事件
    const newDownloadBtn = document.getElementById('downloadBtn');
    if (newDownloadBtn) {
        newDownloadBtn.addEventListener('click', handleDownload);
    }

    // 绑定全选复选框事件
    document.querySelectorAll('.select-all-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const type = this.dataset.type;
            const itemCheckboxes = document.querySelectorAll(`.item-checkbox[data-type="${type}"]`);
            itemCheckboxes.forEach(item => {
                item.checked = this.checked;
            });
        });
    });

    // 绑定音频播放按钮事件
    document.querySelectorAll('.audio-play-button').forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const audioUrl = this.dataset.url;
            const audioId = this.dataset.id;
            toggleAudioPlayback(audioUrl, audioId, this);
        });
    });
}

// 渲染媒体项目
function renderMediaItem(item, type, index) {
    let mediaPreview = '';
    
    // 根据类型生成预览内容
    if (type === 'images') {
        // 图片缩略图（包括WebP）
        const webpBadge = (item.type === 'webp' || item.format === 'webp') ? '<span class="webp-badge">WebP</span>' : '';
        mediaPreview = `
            <img src="${item.thumbnail || item.url}" 
                 class="media-thumbnail loading" 
                 alt="${item.description}"
                 onload="this.classList.remove('loading')"
                 onerror="this.classList.add('error'); this.classList.remove('loading');">
        `;
    } else if (type === 'videos') {
        // 视频缩略图
        const thumbnailUrl = item.thumbnail || item.poster || item.url;
        mediaPreview = `
            <img src="${thumbnailUrl}" 
                 class="media-thumbnail video-thumbnail loading" 
                 alt="${item.description}"
                 onload="this.classList.remove('loading')"
                 onerror="this.classList.add('error'); this.classList.remove('loading');">
        `;
    } else if (type === 'audios') {
        // 音频播放按钮
        const audioId = `audio-${type}-${index}`;
        mediaPreview = `
            <button class="audio-play-button" 
                    data-url="${item.url}" 
                    data-id="${audioId}"
                    title="点击播放/暂停">
                ▶
            </button>
        `;
    } else {
        // 其他类型默认图标
        mediaPreview = `
            <div class="media-thumbnail error">
                ${getTypeIcon(type)}
            </div>
        `;
    }

    return `
        <div class="media-item flex items-center p-2 bg-gray-50 dark:bg-gray-700 rounded hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors">
            ${mediaPreview}
            <input type="checkbox" class="mr-3 item-checkbox" data-type="${type}" data-index="${index}">
            <div class="item-content flex-1 min-w-0">
                <p class="item-title text-sm font-medium text-gray-800 dark:text-gray-200 truncate">
                    ${item.description}
                    ${(item.type === 'webp' || item.format === 'webp') ? '<span class="webp-badge">WebP</span>' : ''}
                </p>
                ${item.url ? `<p class="item-url text-xs text-gray-500 dark:text-gray-400 truncate">${item.url}</p>` : ''}
                ${item.content ? `<p class="text-xs text-gray-600 dark:text-gray-300 mt-1">${item.content}</p>` : ''}
                <p class="item-size text-xs text-gray-400 dark:text-gray-500">大小: ${item.size}</p>
            </div>
        </div>
    `;
}

// 音频播放控制
function toggleAudioPlayback(audioUrl, audioId, buttonElement) {
    try {
        // 检查是否已有播放器实例
        if (audioPlayers.has(audioId)) {
            const audio = audioPlayers.get(audioId);
            if (audio.paused) {
                // 暂停其他音频
                stopAllAudio();
                // 播放当前音频
                audio.play();
                buttonElement.innerHTML = '⏸';
                buttonElement.classList.add('playing');
            } else {
                // 暂停当前音频
                audio.pause();
                buttonElement.innerHTML = '▶';
                buttonElement.classList.remove('playing');
            }
        } else {
            // 创建新的音频播放器
            const audio = new Audio(audioUrl);
            audioPlayers.set(audioId, audio);
            
            // 设置音频事件监听器
            audio.addEventListener('loadstart', () => {
                buttonElement.classList.add('loading');
                buttonElement.innerHTML = '';
            });
            
            audio.addEventListener('canplay', () => {
                buttonElement.classList.remove('loading');
                buttonElement.innerHTML = '⏸';
            });
            
            audio.addEventListener('play', () => {
                buttonElement.innerHTML = '⏸';
                buttonElement.classList.add('playing');
            });
            
            audio.addEventListener('pause', () => {
                buttonElement.innerHTML = '▶';
                buttonElement.classList.remove('playing');
            });
            
            audio.addEventListener('ended', () => {
                buttonElement.innerHTML = '▶';
                buttonElement.classList.remove('playing');
            });
            
            audio.addEventListener('error', (e) => {
                console.error('音频播放错误:', e);
                buttonElement.classList.remove('loading', 'playing');
                buttonElement.innerHTML = '❌';
                showToast('音频播放失败', 'error');
            });
            
            // 暂停其他音频
            stopAllAudio();
            
            // 播放音频
            audio.play().catch(error => {
                console.error('音频播放失败:', error);
                showToast('音频播放失败，可能是跨域限制', 'error');
                buttonElement.classList.remove('loading');
                buttonElement.innerHTML = '❌';
            });
        }
    } catch (error) {
        console.error('音频播放控制失败:', error);
        showToast('音频播放控制失败', 'error');
    }
}

// 停止所有音频播放
function stopAllAudio() {
    audioPlayers.forEach((audio, audioId) => {
        if (!audio.paused) {
            audio.pause();
        }
    });
    
    // 重置所有播放按钮状态
    document.querySelectorAll('.audio-play-button.playing').forEach(button => {
        button.innerHTML = '▶';
        button.classList.remove('playing');
    });
}

// 获取类型图标
function getTypeIcon(type) {
    const icons = {
        images: '🖼️',
        links: '🔗',
        texts: '📝',
        videos: '🎥',
        audios: '🎵',
        streams: '📺'
    };
    return icons[type] || '📄';
}

// 获取类型名称
function getTypeName(type) {
    const names = {
        images: '图片',
        links: '链接',
        texts: '文本',
        videos: '视频',
        audios: '音频',
        streams: '流媒体'
    };
    return names[type] || type;
}

// 上移输入框
function moveInputUp() {
    const inputContainer = document.querySelector('.input-container');
    if (inputContainer) {
        inputContainer.classList.add('animate__animated', 'animate__slideOutUp');
        setTimeout(() => {
            inputContainer.classList.remove('justify-center', 'items-center', 'min-h-screen');
            inputContainer.classList.add('pt-8', 'pb-4');
            inputContainer.classList.remove('animate__animated', 'animate__slideOutUp');
            inputContainer.classList.add('animate__animated', 'animate__slideInDown');
            setTimeout(() => {
                inputContainer.classList.remove('animate__animated', 'animate__slideInDown');
            }, 500);
        }, 300);
    }
}

// 重置输入框位置
function resetInputPosition() {
    const inputContainer = document.querySelector('.input-container');
    if (inputContainer) {
        inputContainer.classList.remove('pt-8', 'pb-4');
        inputContainer.classList.add('justify-center', 'items-center', 'min-h-screen');
    }
}

// 处理下载
async function handleDownload() {
    const selectedItems = [];
    const checkedBoxes = document.querySelectorAll('.item-checkbox:checked');
    
    if (checkedBoxes.length === 0) {
        showToast('请选择要下载的内容', 'error');
        return;
    }

    checkedBoxes.forEach(checkbox => {
        const type = checkbox.dataset.type;
        const index = parseInt(checkbox.dataset.index);
        const item = scanResults.contentTypes[type][index];
        selectedItems.push(item);
    });

    try {
        showLoading(true);
        
        // 检查是否为媒体文件批量下载（包括WebP）
        const mediaTypes = ['image', 'webp', 'video', 'audio', 'stream'];
        const isMediaBatchDownload = selectedItems.length > 1 && 
                                   selectedItems.every(item => mediaTypes.includes(item.type));
        
        const token = localStorage.getItem('token');
        const response = await fetch('/download', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ selectedItems })
        });

        if (response.ok) {
            const contentType = response.headers.get('content-type');
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            
            // 根据内容类型和下载类型设置文件名
            if (contentType === 'application/zip') {
                // ZIP包下载
                a.download = `media-files-${Date.now()}.zip`;
                showToast('批量媒体文件打包下载中...', 'info');
            } else if (contentType.startsWith('image/')) {
                // 单个图片下载（包括WebP）
                const extension = contentType.split('/')[1] || 'jpg';
                const isWebP = selectedItems[0].type === 'webp' || selectedItems[0].format === 'webp';
                a.download = `${isWebP ? 'webp-' : ''}image-${Date.now()}.${extension}`;
            } else if (contentType.startsWith('video/')) {
                // 单个视频下载
                const extension = contentType.split('/')[1] || 'mp4';
                a.download = `video-${Date.now()}.${extension}`;
            } else if (contentType.startsWith('audio/')) {
                // 单个音频下载
                const extension = contentType.split('/')[1] || 'mp3';
                a.download = `audio-${Date.now()}.${extension}`;
            } else if (contentType.startsWith('text/')) {
                // 文本内容下载
                if (isMediaBatchDownload) {
                    // 多媒体链接文本
                    const mediaType = selectedItems[0].type;
                    a.download = `${mediaType}-links-${Date.now()}.txt`;
                } else {
                    // 普通文本
                    a.download = `scan-results-${Date.now()}.txt`;
                }
            } else {
                // 其他类型
                a.download = `download-${Date.now()}`;
            }
            
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
            
            // 根据下载类型显示成功消息
            if (contentType === 'application/zip') {
                showToast('批量媒体文件下载成功', 'success');
            } else if (contentType.startsWith('image/')) {
                const isWebP = selectedItems[0].type === 'webp' || selectedItems[0].format === 'webp';
                showToast(`${isWebP ? 'WebP ' : ''}图片下载成功`, 'success');
            } else if (contentType.startsWith('video/')) {
                showToast('视频下载成功', 'success');
            } else if (contentType.startsWith('audio/')) {
                showToast('音频下载成功', 'success');
            } else {
                showToast('下载成功', 'success');
            }
        } else {
            const data = await response.json();
            showToast(data.message || '下载失败', 'error');
        }
    } catch (error) {
        console.error('下载失败:', error);
        showToast('下载失败，请检查网络连接', 'error');
    } finally {
        showLoading(false);
    }
}

// 显示历史记录模态框
async function showHistoryModal() {
    if (!elements.historyModal) return;

    try {
        showLoading(true);
        
        const token = localStorage.getItem('token');
        const response = await fetch('/history', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (data.success) {
            displayHistory(data.data);
            elements.historyModal.classList.remove('hidden');
            elements.historyModal.classList.add('animate__animated', 'animate__fadeIn');
        } else {
            showToast(data.message || '获取历史记录失败', 'error');
        }
    } catch (error) {
        console.error('获取历史记录失败:', error);
        showToast('获取历史记录失败', 'error');
    } finally {
        showLoading(false);
    }
}

// 显示历史记录
function displayHistory(history) {
    if (!elements.historyContainer) return;

    if (history.length === 0) {
        elements.historyContainer.innerHTML = `
            <div class="text-center py-8 text-gray-500 dark:text-gray-400">
                暂无使用记录
            </div>
        `;
        return;
    }

    let html = '';
    history.forEach(record => {
        const date = new Date(record.timestamp).toLocaleString();
        const contentTypes = record.contentTypes;
        const summary = {
            images: contentTypes.images?.length || 0,
            links: contentTypes.links?.length || 0,
            texts: contentTypes.texts?.length || 0,
            videos: contentTypes.videos?.length || 0,
            audios: contentTypes.audios?.length || 0,
            streams: contentTypes.streams?.length || 0
        };

        html += `
            <div class="border dark:border-gray-600 rounded-lg p-4 hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors">
                <div class="flex justify-between items-start mb-2">
                    <h3 class="font-medium text-gray-800 dark:text-gray-200 truncate flex-1 mr-4">${record.url}</h3>
                    <span class="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">${date}</span>
                </div>
                <div class="grid grid-cols-6 gap-2 text-xs">
                    <div class="text-center">
                        <div class="text-blue-600 dark:text-blue-400">${summary.images}</div>
                        <div class="text-gray-500">图片</div>
                    </div>
                    <div class="text-center">
                        <div class="text-green-600 dark:text-green-400">${summary.links}</div>
                        <div class="text-gray-500">链接</div>
                    </div>
                    <div class="text-center">
                        <div class="text-purple-600 dark:text-purple-400">${summary.texts}</div>
                        <div class="text-gray-500">文本</div>
                    </div>
                    <div class="text-center">
                        <div class="text-red-600 dark:text-red-400">${summary.videos}</div>
                        <div class="text-gray-500">视频</div>
                    </div>
                    <div class="text-center">
                        <div class="text-yellow-600 dark:text-yellow-400">${summary.audios}</div>
                        <div class="text-gray-500">音频</div>
                    </div>
                    <div class="text-center">
                        <div class="text-pink-600 dark:text-pink-400">${summary.streams}</div>
                        <div class="text-gray-500">流媒体</div>
                    </div>
                </div>
            </div>
        `;
    });

    elements.historyContainer.innerHTML = html;
}

// 关闭模态框
function closeModal(modal) {
    if (modal) {
        modal.classList.add('animate__animated', 'animate__fadeOut');
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.classList.remove('animate__animated', 'animate__fadeOut', 'animate__fadeIn');
        }, 300);
    }
}

// 显示加载状态
function showLoading(show) {
    if (elements.loadingSpinner) {
        if (show) {
            elements.loadingSpinner.classList.remove('hidden');
        } else {
            elements.loadingSpinner.classList.add('hidden');
        }
    }
}

// 显示提示消息
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    const bgColor = {
        success: 'bg-green-500',
        error: 'bg-red-500',
        warning: 'bg-yellow-500',
        info: 'bg-blue-500'
    }[type] || 'bg-blue-500';

    toast.className = `fixed top-4 right-4 ${bgColor} text-white px-6 py-3 rounded-lg shadow-lg z-50 animate__animated animate__slideInRight`;
    toast.textContent = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.remove('animate__slideInRight');
        toast.classList.add('animate__slideOutRight');
        setTimeout(() => {
            if (document.body.contains(toast)) {
                document.body.removeChild(toast);
            }
        }, 300);
    }, 3000);
}

// 设置全局错误处理
function setupGlobalErrorHandler() {
    window.addEventListener('error', function(event) {
        console.error('全局错误:', event.error);
        
        // 上报错误到后端
        fetch('/logs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                error: {
                    message: event.error?.message || event.message,
                    stack: event.error?.stack,
                    filename: event.filename,
                    lineno: event.lineno,
                    colno: event.colno
                },
                userAgent: navigator.userAgent,
                url: window.location.href,
                timestamp: new Date().toISOString()
            })
        }).catch(err => {
            console.error('错误上报失败:', err);
        });
        
        showToast('发生未知错误，请刷新页面重试', 'error');
    });

    window.addEventListener('unhandledrejection', function(event) {
        console.error('未处理的Promise拒绝:', event.reason);
        
        // 上报错误到后端
        fetch('/logs', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                error: {
                    message: event.reason?.message || String(event.reason),
                    stack: event.reason?.stack
                },
                userAgent: navigator.userAgent,
                url: window.location.href,
                timestamp: new Date().toISOString()
            })
        }).catch(err => {
            console.error('错误上报失败:', err);
        });
        
        showToast('网络请求失败，请检查连接', 'error');
    });
}